const hx = require("../hbxBridge.js");
const metatypes = require("./metatypes.js");
const Disposable = require("./disposable.js");
const TextDocument = require("./texteditor.js").TextDocument;
const TextEdit = require("./texteditor.js").TextEdit;
const configService = require("./configuration.js");
let hasInited = false;
let documentListeners = {
	willSaveTextDocument: [],
	didChangeTextDocument: [],
	onDidSaveTextDocument:[]
}

function _init(connection) {
	if (hasInited) {
		return;
	}
	hasInited = true;
	configService.init(connection);
	connection.onRequest("sendEvent", function(event) {
		let eventId = event.id;
		if (eventId in documentListeners) {
			let listeners = documentListeners[eventId];
			let doc = metatypes.newObject(event.data);
			for (let i = 0; i < listeners.length; i++) {
				let listener = listeners[i];
				if (listener) {
					listener(doc);
				}
			}
		}
		return true
	});
	connection.onNotification("postEvent", function(event) {
		let eventId = event.id;
		if (eventId in documentListeners) {
			let listeners = documentListeners[eventId];
			let doc = metatypes.newObject(event.data);
			for (let i = 0; i < listeners.length; i++) {
				let listener = listeners[i];
				if (listener) {
					listener(doc);
				}
			}
		}
	});
}

function WorkspaceEdit() {
	let entries = {};

	this.set = function(uri, edits) {
		let uriKey = uri;
		if (uri.fsPath && uri.fsPath.length > 0) {
			uriKey = uri.fsPath;
		}
		entries[uriKey] = edits;
	}

	this.entries = function() {
		return entries;
	}
}

function onWillSaveTextDocument(listener) {
	documentListeners.willSaveTextDocument.push(listener);
    return new Disposable(function(){
        let index = documentListeners.willSaveTextDocument.indexOf(listener);
        if(index > -1){
            documentListeners.willSaveTextDocument.splice(index,1);
        }
    });
}

function onDidChangeTextDocument(listener) {
	documentListeners.didChangeTextDocument.push(listener);
    return new Disposable(function(){
        let index = documentListeners.didChangeTextDocument.indexOf(listener);
        if(index > -1){
            documentListeners.didChangeTextDocument.splice(index,1);
        }
    });
}
//onDidSaveTextDocument
function onDidSaveTextDocument(listener) {
	documentListeners.onDidSaveTextDocument.push(listener);
    return new Disposable(function(){
        let index = documentListeners.onDidSaveTextDocument.indexOf(listener);
        if(index > -1){
            documentListeners.onDidSaveTextDocument.splice(index,1);
        }
    });
}
/**
 * 修改文档
 * @param {WorkspaceEdit} edit
 */
function applyEdit(edit) {
	if (edit) {
		hx.request("workspace.applyEdit", edit.entries());
	}
}

function openTextDocument(uri){
	return hx.request("workspace.openTextDocument",uri);
}

/**
 * 获取当前项目
 * @param {Uri} uri
 */
function getWorkspaceFolder(uri) {
	// hx.request("workspace.getWorkspaceFolder",{
	//     uri:uri
	// });
}

/**
 * @param {String} section
 * @param {ConfigurationScope} scope
 */
function getConfiguration(section, scope) {
	return new configService.Configuration(section, scope);
}

module.exports = {
	init: _init,
	fs: {},
	workspaceFolders: [],
	onWillSaveTextDocument: onWillSaveTextDocument,
	onDidChangeTextDocument: onDidChangeTextDocument,
	onDidSaveTextDocument:onDidSaveTextDocument,
	openTextDocument:openTextDocument,
	applyEdit: applyEdit,
	getWorkspaceFolder: getWorkspaceFolder,
	getConfiguration: getConfiguration,
	WorkspaceEdit: WorkspaceEdit,
	TextEdit: TextEdit
}
