const hx = require("../hbxBridge.js")

const $globalConfiguration = {};
module.exports.init = function(connection){
	connection.onRequest("workspace/syncGlobalConfigurations",function(globalConfiguration){
		if(globalConfiguration["default"]){
			$globalConfiguration["default"] = globalConfiguration["default"];
		}
		
		if(globalConfiguration["user"]){
			$globalConfiguration["user"] = globalConfiguration["user"]
		}
	});
}

module.exports.Configuration = function(_section,_scope){
	let section = _section;
	let scope = _scope;
	
	function getFullSection(_section){
		if(section !== undefined){
			_section = section + "." + _section;
		}
		return _section;
	}
	
	this.get = function(section,defaultValue){
		let key = getFullSection(section);
		if($globalConfiguration["user"] && $globalConfiguration["user"].hasOwnProperty(key)){
			return $globalConfiguration["user"][key];
		}
		if($globalConfiguration["default"] && $globalConfiguration["default"].hasOwnProperty(key)){
			return $globalConfiguration["default"][key];
		}
		return defaultValue;
	}
	
	this.update = function(section,value){
		let key = getFullSection(section);
		if($globalConfiguration["user"]){
			$globalConfiguration["user"][key] = value;
		}
		return hx.request("configuration.update",{
			section:getFullSection(section),
			value:value
		});
	}
}