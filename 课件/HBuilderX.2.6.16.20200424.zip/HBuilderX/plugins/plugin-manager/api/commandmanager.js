const hx = require('../hbxBridge.js');
const Disposable = require("./disposable.js");
let commands = {};

function _init(connection){
	connection.onRequest("command/execute", function(param){
	    try{
	        console.error("command/execute:" + param.id);
	        executeCommand(param.id,param.params)
	    }catch(e){
	        console.error(e);
	        return false;
	    }
	    return true
	});
}

function registerCommand(id,handler){
    if(commands[id]){
        console.error("command id ["+id+"] already exists.");
        return ;
    }
    commands[id] = handler;
    return new Disposable(function(){
        commands[id] = undefined;
    });
}

function registerTextEditorCommand(id,handler){
	let disposable = registerCommand(id,handler);
	commands[id].isEditorCommand = true;
    return disposable;
}

function executeCommand(id,params){
    if(commands[id]){
		if(commands[id].isEditorCommand){
			let activeEditor = hx.window.getActiveTextEditor();
			activeEditor.then(function(editor){
				commands[id](editor);
			});
		}else{
			commands[id](params);
		}
    }else{
        throw ("command id ["+id+"] not registed yet.");
    }
}

module.exports = {
	init:_init,
    registerCommand:registerCommand,
    executeCommand:executeCommand,
	registerTextEditorCommand:registerTextEditorCommand
}